# MERCA MALIK 3: sitio estático para Vercel

## Estructura
index.html · 404.html · vercel.json · robots.txt
assets/css/styles.css · assets/js/main.js · assets/js/tailwind-config.js · assets/logo.svg · assets/images/

## Imágenes (haz esto antes de publicar)
Las fotos originales son enlaces temporales de Instagram/Google/Apple y dejarán de cargar.
Descárgalas y guárdalas en `assets/images/` con estos nombres exactos (.jpg):
logo, poster-windows, poster-iphone, poster-repair, tienda-fachada, tienda-moviles, tienda-accesorios, tienda-taller.
Mientras no existan, la página usa el enlace original como respaldo y, si también falla, `assets/logo.svg`.

## Desplegar en Vercel
- CLI: `npm i -g vercel`, luego `vercel` y `vercel --prod` dentro de esta carpeta (Framework: Other, sin build).
- GitHub: sube la carpeta a un repo, importa en vercel.com/new, Framework "Other", sin comando de build.
